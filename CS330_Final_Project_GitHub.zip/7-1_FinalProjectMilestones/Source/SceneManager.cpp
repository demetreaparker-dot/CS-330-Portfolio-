///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  Modified for CS 330 Milestone Two
//  Complex animatronic head constructed from basic 3D shapes.
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

///////////////////////////////////////////////////////////////////////////////
// SceneManager()
///////////////////////////////////////////////////////////////////////////////
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

///////////////////////////////////////////////////////////////////////////////
// ~SceneManager()
///////////////////////////////////////////////////////////////////////////////
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;

	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

///////////////////////////////////////////////////////////////////////////////
// CreateGLTexture()
///////////////////////////////////////////////////////////////////////////////
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	stbi_set_flip_vertically_on_load(true);

	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	if (image)
	{
		std::cout << "Successfully loaded image:"
			<< filename
			<< ", width:" << width
			<< ", height:" << height
			<< ", channels:" << colorChannels
			<< std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (colorChannels == 3)
		{
			glTexImage2D(
				GL_TEXTURE_2D,
				0,
				GL_RGB8,
				width,
				height,
				0,
				GL_RGB,
				GL_UNSIGNED_BYTE,
				image);
		}
		else if (colorChannels == 4)
		{
			glTexImage2D(
				GL_TEXTURE_2D,
				0,
				GL_RGBA8,
				width,
				height,
				0,
				GL_RGBA,
				GL_UNSIGNED_BYTE,
				image);
		}
		else
		{
			std::cout
				<< "Not implemented to handle image with "
				<< colorChannels
				<< " channels"
				<< std::endl;

			return false;
		}

		glGenerateMipmap(GL_TEXTURE_2D);

		stbi_image_free(image);

		glBindTexture(GL_TEXTURE_2D, 0);

		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout
		<< "Could not load image:"
		<< filename
		<< std::endl;

	return false;
}

///////////////////////////////////////////////////////////////////////////////
// BindGLTextures()
///////////////////////////////////////////////////////////////////////////////
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glActiveTexture(GL_TEXTURE0 + i);

		glBindTexture(
			GL_TEXTURE_2D,
			m_textureIDs[i].ID);
	}
}

///////////////////////////////////////////////////////////////////////////////
// DestroyGLTextures()
///////////////////////////////////////////////////////////////////////////////
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(
			1,
			&m_textureIDs[i].ID);
	}
}

///////////////////////////////////////////////////////////////////////////////
// FindTextureID()
///////////////////////////////////////////////////////////////////////////////
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) &&
		(bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
		{
			index++;
		}
	}

	return(textureID);
}

///////////////////////////////////////////////////////////////////////////////
// FindTextureSlot()
///////////////////////////////////////////////////////////////////////////////
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) &&
		(bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
		{
			index++;
		}
	}

	return(textureSlot);
}

///////////////////////////////////////////////////////////////////////////////
// FindMaterial()
///////////////////////////////////////////////////////////////////////////////
bool SceneManager::FindMaterial(
	std::string tag,
	OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;

	while ((index < m_objectMaterials.size()) &&
		(bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;

			material.diffuseColor =
				m_objectMaterials[index].diffuseColor;

			material.specularColor =
				m_objectMaterials[index].specularColor;

			material.shininess =
				m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

///////////////////////////////////////////////////////////////////////////////
// SetTransformations()
///////////////////////////////////////////////////////////////////////////////
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	scale = glm::scale(scaleXYZ);

	rotationX = glm::rotate(
		glm::radians(XrotationDegrees),
		glm::vec3(1.0f, 0.0f, 0.0f));

	rotationY = glm::rotate(
		glm::radians(YrotationDegrees),
		glm::vec3(0.0f, 1.0f, 0.0f));

	rotationZ = glm::rotate(
		glm::radians(ZrotationDegrees),
		glm::vec3(0.0f, 0.0f, 1.0f));

	translation = glm::translate(positionXYZ);

	modelView =
		translation *
		rotationZ *
		rotationY *
		rotationX *
		scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(
			g_ModelName,
			modelView);
	}
}

///////////////////////////////////////////////////////////////////////////////
// SetShaderColor()
///////////////////////////////////////////////////////////////////////////////
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(
			g_UseTextureName,
			false);

		m_pShaderManager->setVec4Value(
			g_ColorValueName,
			currentColor);
	}
}

///////////////////////////////////////////////////////////////////////////////
// SetShaderTexture()
///////////////////////////////////////////////////////////////////////////////
void SceneManager::SetShaderTexture(std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(
			g_UseTextureName,
			true);

		int textureID = -1;

		textureID =
			FindTextureSlot(textureTag);

		m_pShaderManager->setSampler2DValue(
			g_TextureValueName,
			textureID);
	}
}

///////////////////////////////////////////////////////////////////////////////
// SetTextureUVScale()
///////////////////////////////////////////////////////////////////////////////
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value(
			"UVscale",
			glm::vec2(u, v));
	}
}

///////////////////////////////////////////////////////////////////////////////
// SetShaderMaterial()
///////////////////////////////////////////////////////////////////////////////
void SceneManager::SetShaderMaterial(std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn =
			FindMaterial(
				materialTag,
				material);

		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value(
				"material.diffuseColor",
				material.diffuseColor);

			m_pShaderManager->setVec3Value(
				"material.specularColor",
				material.specularColor);

			m_pShaderManager->setFloatValue(
				"material.shininess",
				material.shininess);
		}
	}
}

/***********************************************************
 * STUDENTS CAN MODIFY THE CODE BELOW
 ***********************************************************/

 ///////////////////////////////////////////////////////////////////////////////
 // PrepareScene()
 //
 // Load all primitive meshes needed to construct the
 // animatronic head.
 ///////////////////////////////////////////////////////////////////////////////
void SceneManager::PrepareScene()
{
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadCylinderMesh();
}

///////////////////////////////////////////////////////////////////////////////
// RenderScene()
//
// Creates a simplified 3D version of the yellow animatronic
// head shown in the Milestone One reference image.
//
// Multiple primitive meshes are combined using scaling,
// rotation, and translation transformations.
///////////////////////////////////////////////////////////////////////////////
void SceneManager::RenderScene()
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;


	// ============================================================
	// FLOOR
	// ============================================================

	scaleXYZ = glm::vec3(12.0f, 1.0f, 10.0f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(
		0.0f,
		-2.80f,
		0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.12f,
		0.12f,
		0.15f,
		1.0f);

	m_basicMeshes->DrawPlaneMesh();


	// ============================================================
	// MAIN YELLOW HEAD
	// ============================================================

	scaleXYZ = glm::vec3(
		3.25f,
		2.65f,
		2.10f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -3.0f;

	positionXYZ = glm::vec3(
		0.0f,
		0.75f,
		0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		1.0f,
		0.76f,
		0.02f,
		1.0f);

	m_basicMeshes->DrawSphereMesh();


	// ============================================================
	// LEFT EYE SOCKET
	// ============================================================

	scaleXYZ = glm::vec3(
		0.82f,
		1.02f,
		0.30f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -13.0f;

	positionXYZ = glm::vec3(
		-1.15f,
		1.35f,
		2.02f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.01f,
		0.01f,
		0.01f,
		1.0f);

	m_basicMeshes->DrawSphereMesh();


	// ============================================================
	// RIGHT EYE SOCKET
	// ============================================================

	scaleXYZ = glm::vec3(
		0.82f,
		1.02f,
		0.30f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 13.0f;

	positionXYZ = glm::vec3(
		1.15f,
		1.35f,
		2.02f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.01f,
		0.01f,
		0.01f,
		1.0f);

	m_basicMeshes->DrawSphereMesh();


	// ============================================================
	// LEFT EYE HIGHLIGHT
	// ============================================================

	scaleXYZ = glm::vec3(
		0.14f,
		0.17f,
		0.10f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(
		-0.93f,
		1.55f,
		2.32f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		1.0f,
		1.0f,
		1.0f,
		1.0f);

	m_basicMeshes->DrawSphereMesh();


	// ============================================================
	// RIGHT EYE HIGHLIGHT
	// ============================================================

	scaleXYZ = glm::vec3(
		0.14f,
		0.17f,
		0.10f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(
		1.37f,
		1.55f,
		2.32f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		1.0f,
		1.0f,
		1.0f,
		1.0f);

	m_basicMeshes->DrawSphereMesh();


	// ============================================================
	// LEFT CHEEK
	// ============================================================

	scaleXYZ = glm::vec3(
		0.52f,
		0.52f,
		0.32f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(
		-2.25f,
		0.15f,
		1.72f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.95f,
		0.05f,
		0.30f,
		1.0f);

	m_basicMeshes->DrawSphereMesh();


	// ============================================================
	// RIGHT CHEEK
	// ============================================================

	scaleXYZ = glm::vec3(
		0.52f,
		0.52f,
		0.32f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(
		2.25f,
		0.15f,
		1.72f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.95f,
		0.05f,
		0.30f,
		1.0f);

	m_basicMeshes->DrawSphereMesh();


	// ============================================================
	// LEFT HALF OF MUZZLE
	// ============================================================

	scaleXYZ = glm::vec3(
		1.20f,
		0.58f,
		0.62f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -6.0f;

	positionXYZ = glm::vec3(
		-0.62f,
		0.15f,
		2.05f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		1.0f,
		0.60f,
		0.0f,
		1.0f);

	m_basicMeshes->DrawSphereMesh();


	// ============================================================
	// RIGHT HALF OF MUZZLE
	// ============================================================

	scaleXYZ = glm::vec3(
		1.20f,
		0.58f,
		0.62f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 6.0f;

	positionXYZ = glm::vec3(
		0.62f,
		0.15f,
		2.05f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		1.0f,
		0.60f,
		0.0f,
		1.0f);

	m_basicMeshes->DrawSphereMesh();


	// ============================================================
	// OPEN MOUTH
	// ============================================================

	scaleXYZ = glm::vec3(
		1.65f,
		0.62f,
		0.27f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -2.0f;

	positionXYZ = glm::vec3(
		0.0f,
		-0.78f,
		2.12f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.015f,
		0.015f,
		0.015f,
		1.0f);

	m_basicMeshes->DrawBoxMesh();


	// ============================================================
	// UPPER TEETH
	// ============================================================

	scaleXYZ = glm::vec3(0.20f, 0.27f, 0.16f);
	positionXYZ = glm::vec3(-1.05f, -0.50f, 2.43f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(
		0.93f,
		0.88f,
		0.68f,
		1.0f);

	m_basicMeshes->DrawBoxMesh();


	scaleXYZ = glm::vec3(0.20f, 0.30f, 0.16f);
	positionXYZ = glm::vec3(-0.52f, -0.48f, 2.43f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(
		0.93f,
		0.88f,
		0.68f,
		1.0f);

	m_basicMeshes->DrawBoxMesh();


	scaleXYZ = glm::vec3(0.20f, 0.30f, 0.16f);
	positionXYZ = glm::vec3(0.0f, -0.48f, 2.43f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(
		0.93f,
		0.88f,
		0.68f,
		1.0f);

	m_basicMeshes->DrawBoxMesh();


	scaleXYZ = glm::vec3(0.20f, 0.30f, 0.16f);
	positionXYZ = glm::vec3(0.52f, -0.48f, 2.43f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(
		0.93f,
		0.88f,
		0.68f,
		1.0f);

	m_basicMeshes->DrawBoxMesh();


	scaleXYZ = glm::vec3(0.20f, 0.27f, 0.16f);
	positionXYZ = glm::vec3(1.05f, -0.50f, 2.43f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(
		0.93f,
		0.88f,
		0.68f,
		1.0f);

	m_basicMeshes->DrawBoxMesh();


	// ============================================================
	// LOWER TEETH
	// ============================================================

	scaleXYZ = glm::vec3(0.18f, 0.22f, 0.16f);
	positionXYZ = glm::vec3(-0.78f, -1.05f, 2.43f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(
		0.93f,
		0.88f,
		0.68f,
		1.0f);

	m_basicMeshes->DrawBoxMesh();


	scaleXYZ = glm::vec3(0.18f, 0.22f, 0.16f);
	positionXYZ = glm::vec3(-0.25f, -1.05f, 2.43f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(
		0.93f,
		0.88f,
		0.68f,
		1.0f);

	m_basicMeshes->DrawBoxMesh();


	scaleXYZ = glm::vec3(0.18f, 0.22f, 0.16f);
	positionXYZ = glm::vec3(0.28f, -1.05f, 2.43f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(
		0.93f,
		0.88f,
		0.68f,
		1.0f);

	m_basicMeshes->DrawBoxMesh();


	scaleXYZ = glm::vec3(0.18f, 0.22f, 0.16f);
	positionXYZ = glm::vec3(0.80f, -1.05f, 2.43f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(
		0.93f,
		0.88f,
		0.68f,
		1.0f);

	m_basicMeshes->DrawBoxMesh();


	// ============================================================
	// LOWER YELLOW JAW
	// ============================================================

	scaleXYZ = glm::vec3(
		1.75f,
		0.38f,
		0.58f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -3.0f;

	positionXYZ = glm::vec3(
		0.0f,
		-1.48f,
		1.88f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		1.0f,
		0.64f,
		0.0f,
		1.0f);

	m_basicMeshes->DrawSphereMesh();


	// ============================================================
	// LEFT TOP FEATHER
	// Cylinder rotated outward from center.
	// ============================================================

	scaleXYZ = glm::vec3(
		0.20f,
		1.15f,
		0.20f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 35.0f;

	positionXYZ = glm::vec3(
		-0.75f,
		3.55f,
		0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		1.0f,
		0.76f,
		0.02f,
		1.0f);

	m_basicMeshes->DrawCylinderMesh();


	// ============================================================
	// CENTER TOP FEATHER
	// ============================================================

	scaleXYZ = glm::vec3(
		0.22f,
		1.25f,
		0.22f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(
		0.0f,
		3.80f,
		0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		1.0f,
		0.76f,
		0.02f,
		1.0f);

	m_basicMeshes->DrawCylinderMesh();


	// ============================================================
	// RIGHT TOP FEATHER
	// ============================================================

	scaleXYZ = glm::vec3(
		0.20f,
		1.15f,
		0.20f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -35.0f;

	positionXYZ = glm::vec3(
		0.75f,
		3.55f,
		0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		1.0f,
		0.76f,
		0.02f,
		1.0f);

	m_basicMeshes->DrawCylinderMesh();


	// ============================================================
	// LEFT FEATHER TIP
	// ============================================================

	scaleXYZ = glm::vec3(
		0.30f,
		0.55f,
		0.30f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 35.0f;

	positionXYZ = glm::vec3(
		-1.40f,
		4.25f,
		0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		1.0f,
		0.76f,
		0.02f,
		1.0f);

	m_basicMeshes->DrawConeMesh();


	// ============================================================
	// CENTER FEATHER TIP
	// ============================================================

	scaleXYZ = glm::vec3(
		0.30f,
		0.55f,
		0.30f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(
		0.0f,
		4.75f,
		0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		1.0f,
		0.76f,
		0.02f,
		1.0f);

	m_basicMeshes->DrawConeMesh();


	// ============================================================
	// RIGHT FEATHER TIP
	// ============================================================

	scaleXYZ = glm::vec3(
		0.30f,
		0.55f,
		0.30f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -35.0f;

	positionXYZ = glm::vec3(
		1.40f,
		4.25f,
		0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		1.0f,
		0.76f,
		0.02f,
		1.0f);

	m_basicMeshes->DrawConeMesh();
}